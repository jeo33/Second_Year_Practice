package system;

public class Quotations {

}
